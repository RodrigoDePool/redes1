#ifndef PRACTICA1_H
#define PRACTICA1_H

#define OK 0
#define ERROR -1
#define TWODAYS_SECS 172800
#define ETH_FRAME_MAX 2048// Tamanio maximo trama ethernet

#endif
